# 💡 Tarjeta LED
**Autor:** Jorge

Tarjeta personalizada basada en *Mushroom Light Card*, con estilo **card-mod 3**:
- Fondo transparente  
- Borde negro fino  
- Texto negro  
- Totalmente interactiva con control de brillo, color y temperatura  

Perfecta para integrar con el tema visual negro/blanco de Home Assistant.
